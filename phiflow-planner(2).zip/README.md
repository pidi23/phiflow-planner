# PhiFlow Planner (2‑Wochen Immersion)

React + Vite + Tailwind + Recharts. Planer für Sprachimmersion.

## Quickstart

```bash
npm install
npm run dev
```

Dann im Browser öffnen: die Konsole zeigt die URL (z. B. http://localhost:5173).

## Deploy
- Vercel/Netlify: Projektordner hochladen → Build Command: `npm run build`, Output: `dist/`.
